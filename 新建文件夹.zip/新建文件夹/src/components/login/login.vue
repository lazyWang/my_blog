<template>
 <div class="main">
    <el-input placeholder="请输入帐号" v-model="input3"  prefix-icon="el-icon-service">
        <template slot="prepend">帐号</template>
    </el-input>
    <br>
    <br>
    <el-input placeholder="请输入昵称" v-model="input3"  prefix-icon="el-icon-edit">
        <template slot="prepend">昵称</template>
    </el-input>
    <br>
    <br>
    <el-input type="password" placeholder="请输入密码" v-model="input3"  prefix-icon="el-icon-goods">
        <template slot="prepend">密码</template>
    </el-input>
    <br>
    <br>
    <el-button  class="login" type="primary" size="small">登录</el-button>
    <span  class="resgister">还没有帐号，前往注册</span>
 </div>
</template>

<script>
export default {
 data () {
 return {
 };
 },

 components: {},

 computed: {},

 mounted: {},

 methods: {}
}

</script>
<style  scoped>
.main{
    padding: 10px;
    border: 1px solid rgb(238, 238, 238)
}

.resgister{
    margin-left: 10px;
    color:#409EFF;
    font-size: 12px;
}
</style>