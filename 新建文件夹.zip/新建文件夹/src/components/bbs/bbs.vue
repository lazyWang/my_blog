<template>
 <div>
    <div class="breadvrumb-line">
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>留言板</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="maxim">大丈夫处世处，当交四海英雄</div>
    </div>
    <div class="bbs-main">
        <el-col class="content-left" :span="15">
            <div class="reselt-main">
                <el-input type="textarea" :rows="4" maxlength="200" placeholder="请输入留言内容，最多输入200字" v-model="textarea" resize="none"></el-input>
                <el-button class="publish" @click="open3" type="success" size="medium">发表</el-button>
            </div>
            <div class="reselt-content" v-for="(item,index) in 10" :key="index">
                <el-col class="reselt-content-left" :span="4">
                    <img class="reselt-content-left-img" src="../../../static/photo/people/12.jpg" alt="">
                    <p class="reselt-content-left-name">冰激凌sqb</p>
                </el-col>
                <el-col class="reselt-content-right" :span="20">
                    <div>其实我的分数可以去拼一下会计那些专业，不过我不喜欢就没填。当我高中尝试了学金融之后我就知道我并不喜欢会计那些，热门并不代表自己就喜欢那个专业。没有兴趣学起来就是折磨</div>
                    <p class="creat-time">2017-06-08 20:45  <span>回复</span></p>
                </el-col>
            </div>
            <div class="block">
                <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="currentPage4"
                    :page-sizes="[10, 20, 30, 40]"
                    :page-size="10"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="400">
                </el-pagination>
            </div>
        </el-col>
        <el-col class="content-right" :offset="3" :span="6">
            <div v-if="login"  class="content-right-info">
                <img class="content-right-info-img" src="../../../static/photo/people/14.jpg" alt="">
                <img class="infobg" src="../../../static/images/infobg.png" alt="">
                <div class="ln1">
                    <span>👑宏宏猪</span>
                    <span class="ln2">退出登录</span>
                </div>
            </div>
            <div v-else class="content-right-info">
                <img class="content-right-info-img" src="https://gss0.bdstatic.com/6LZ1dD3d1sgCo2Kml5_Y_D3/sys/portrait/item/0602b0aecef7b3bd3058" alt="">
                <img class="infobg" src="../../../static/images/infobg.png" alt="">
                <div class="ln1">
                    <span>游客</span>
                    <span class="ln2">登录</span>
                </div>
            </div>
            <login></login>
        </el-col>        
    </div>
 </div>
</template>

<script>
import login from '../login/login';
export default {
 data () {
 return {
     login:true,
     currentPage4: 1
    };
 },
 components:{
    login
 },
 methods: {
    open3() {
        this.$prompt('请输入邮箱', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputPattern: /[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/,
          inputErrorMessage: '邮箱格式不正确'
        }).then(({ value }) => {
          this.$message({
            type: 'success',
            message: '你的邮箱是: ' + value
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消输入'
          });       
        });
      }
    }
}

</script>
<style  scoped>
.breadvrumb-line {
  padding-bottom: 20px;
  position: relative;
  border-bottom: 1px solid #999;
}
.maxim{
    position: absolute;
    top: 0;
    right: 20px;
    font-size: 12px;
}

.bbs-main{
    margin-top: 20px;
    text-align: left;
}
.reselt-main{
    border-radius: 5px;
    padding: 20px 10px 10px;
    border:1px solid rgb(238, 238, 238);
    margin-bottom: 30px;
}
.publish{
    margin-top: 10px;
}
.reselt-content{
    border:1px solid rgb(238, 238, 238);
    padding: 10px 0;
    height: 150px;
    position: relative;
}
.reselt-content-left{
    float: left;
}
.reselt-content-left-img{
    display: block;
    margin: 0 auto;
    height: 75px;
    width: 75px;
    border:2px solid rgb(232, 233, 234);
}

.reselt-content-left-name{
    color: #409EFF;
    margin-top: 5px;
    font-size: 14px;
    text-align: center;
}
.reselt-content-right{
    float: right;
    line-height: 24px;
    font-size: 14px;
    word-wrap: break-word;
    overflow: hidden;
    color: #333;
}
.creat-time{
    position: absolute;
    bottom: 10px;
    right: 25px;
    color: #999;
    font-size: 12px;
}
.creat-time span{
    color: #409EFF;
}
.block{
    margin-top: 10px;
}
.content-right-info{
    padding: 20px 10px;
    border: 1px solid rgb(238, 238, 238);
    text-align: center;
    height: 150px;
    border-radius: 5px;
    position: relative;
}
.content-right-info-img{
    /* margin: 0 auto 10px; */
    padding: 4px;
    float: left;
    margin-left: 10px;
    /* display: block; */
    border: 1px solid rgb(238, 238, 238);
    width: 90px;
    height: 90px;
}
.infobg{
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 30px;
}
.ln1{
    float: left;
    /* width: 90px; */
    margin:10px 10px;
}
.ln1 span{
    display: block;
    font-size: 12px;
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    color: #333;
    line-height: 22px;
}
.ln1 .ln2{
    color: #409EFF;
}
</style>